# Code Negar Android 2.0

A Kotlin + Jetpack Compose video editing project for Android.

## Features
- Import multiple video clips
- Preview and reorder clips on a timeline
- Trim and split the selected clip
- Add background audio and adjust its volume
- Add a text overlay with color and position controls
- Export the project as an MP4 video
- Save and restore project files (JSON)
- Persian and English interface; use the language button in the top bar to switch

## Build
1. Extract the ZIP archive.
2. Open the project folder in Android Studio.
3. Allow Gradle sync and install the required Android SDK.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated debug APK is normally located at `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 8.0 (API 26). Compile/target SDK: 35.
