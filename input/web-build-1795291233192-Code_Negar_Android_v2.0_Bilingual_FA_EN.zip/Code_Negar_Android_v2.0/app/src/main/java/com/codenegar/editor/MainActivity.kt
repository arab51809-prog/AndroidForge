package com.codenegar.editor

import android.net.Uri
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Color as AndroidColor
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.MediaItem.ClippingConfiguration
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.Locale

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF141827)
private val Panel2 = Color(0xFF202A40)
private val Neon = Color(0xFF9B5CFF)
private val Cyan = Color(0xFF25D9F2)
private val Muted = Color(0xFF9AA4B8)

private fun tx(english: Boolean, persian: String, englishText: String): String =
    if (english) englishText else persian

private data class Clip(val uri: Uri, val label: String, val startMs: Long = 0L, val endMs: Long? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CodeNegarApp() }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun CodeNegarApp() {
    val context = LocalContext.current
    val clips = remember { mutableStateListOf<Clip>() }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var trimStartMs by remember { mutableLongStateOf(0L) }
    var trimEndMs by remember { mutableLongStateOf(0L) }
    var exporting by remember { mutableStateOf(false) }
    var musicUri by remember { mutableStateOf<Uri?>(null) }
    var musicVolume by remember { mutableFloatStateOf(0.75f) }
    var overlayText by remember { mutableStateOf("") }
    var overlayColorIndex by remember { mutableIntStateOf(0) }
    var overlayPosition by remember { mutableIntStateOf(0) }
    var showTextDialog by remember { mutableStateOf(false) }
    val overlayColors = listOf(AndroidColor.WHITE, AndroidColor.YELLOW, AndroidColor.CYAN, AndroidColor.RED)
    var isEnglish by rememberSaveable { mutableStateOf(false) }
    var status by remember { mutableStateOf("چند ویدیو وارد کن و ترتیب آن‌ها را بچین") }
    var selectedTool by remember { mutableStateOf("clips") }
    var pendingProjectJson by remember { mutableStateOf("") }

    val musicPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            volume = musicVolume
        }
    }
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        durationMs = duration.coerceAtLeast(0L)
                        if (trimEndMs == 0L || trimEndMs > durationMs) trimEndMs = durationMs
                    }
                }
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    selectedIndex = currentMediaItemIndex.coerceAtLeast(0)
                    positionMs = 0L
                    trimStartMs = 0L
                    trimEndMs = 0L
                }
            })
        }
    }
    DisposableEffect(Unit) { onDispose { player.release(); musicPlayer.release() } }

    fun refreshPlaylist(startAt: Int = selectedIndex, autoplay: Boolean = false) {
        if (clips.isEmpty()) {
            player.clearMediaItems()
            selectedIndex = 0
            durationMs = 0L
            positionMs = 0L
            return
        }
        selectedIndex = startAt.coerceIn(0, clips.lastIndex)
        val items = clips.map { clip ->
            val clipping = ClippingConfiguration.Builder()
                .setStartPositionMs(clip.startMs)
                .setEndPositionMs(clip.endMs ?: C.TIME_END_OF_SOURCE)
                .build()
            MediaItem.Builder().setUri(clip.uri).setClippingConfiguration(clipping).build()
        }
        player.setMediaItems(items, selectedIndex, 0L)
        player.prepare()
        player.playWhenReady = autoplay
        durationMs = 0L
        positionMs = 0L
        trimStartMs = 0L
        trimEndMs = 0L
    }

    val multiPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val wasEmpty = clips.isEmpty()
            uris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: SecurityException) { }
                clips.add(Clip(uri, "${tx(isEnglish, "کلیپ", "Clip")} ${clips.size + 1}"))
            }
            if (wasEmpty) refreshPlaylist(0, false)
            status = if (isEnglish) "${uris.size} video(s) added to the timeline; file access is retained for this project" else "${uris.size} ویدیو به تایم‌لاین اضافه شد؛ دسترسی فایل‌ها برای پروژه حفظ شد"
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: SecurityException) { }
            musicUri = uri
            musicPlayer.setMediaItem(MediaItem.fromUri(uri))
            musicPlayer.repeatMode = Player.REPEAT_MODE_ONE
            musicPlayer.volume = musicVolume
            musicPlayer.prepare()
            if (player.isPlaying) musicPlayer.play()
            status = tx(isEnglish, "موسیقی پس‌زمینه اضافه شد", "Background music added")
        }
    }

    val saveProjectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingProjectJson) }
                status = tx(isEnglish, "فایل پروژه با موفقیت ذخیره شد", "Project file saved successfully")
            } catch (error: Exception) {
                status = if (isEnglish) "Error saving project: ${error.message ?: "Unknown"}" else "خطا در ذخیره پروژه: ${error.message ?: "نامشخص"}"
            }
        }
    }

    val loadProjectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: SecurityException) { }
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error(tx(isEnglish, "فایل پروژه خوانده نشد", "Could not read project file"))
                val json = JSONObject(raw)
                val clipArray = json.getJSONArray("clips")
                val restored = mutableListOf<Clip>()
                for (i in 0 until clipArray.length()) {
                    val item = clipArray.getJSONObject(i)
                    val clipUri = Uri.parse(item.getString("uri"))
                    try { context.contentResolver.takePersistableUriPermission(clipUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    catch (_: SecurityException) { }
                    val end = if (item.isNull("endMs")) null else item.getLong("endMs")
                    restored.add(Clip(clipUri, item.optString("label", "${tx(isEnglish, "کلیپ", "Clip")} ${i + 1}"), item.optLong("startMs", 0L), end))
                }
                clips.clear()
                clips.addAll(restored)
                selectedIndex = json.optInt("selectedIndex", 0).coerceIn(0, (clips.size - 1).coerceAtLeast(0))
                overlayText = json.optString("overlayText", "")
                overlayColorIndex = json.optInt("overlayColorIndex", 0).coerceIn(0, 3)
                overlayPosition = json.optInt("overlayPosition", 0).coerceIn(0, 2)
                musicVolume = json.optDouble("musicVolume", 0.75).toFloat().coerceIn(0f, 1f)
                val savedMusic = json.optString("musicUri", "")
                musicUri = if (savedMusic.isBlank()) null else Uri.parse(savedMusic)
                if (musicUri != null) {
                    musicPlayer.setMediaItem(MediaItem.fromUri(musicUri!!))
                    musicPlayer.volume = musicVolume
                    musicPlayer.repeatMode = Player.REPEAT_MODE_ONE
                    musicPlayer.prepare()
                } else musicPlayer.stop()
                refreshPlaylist(selectedIndex, false)
                status = if (isEnglish) "Project loaded with ${clips.size} clip(s)" else "پروژه با ${clips.size} کلیپ بارگذاری شد"
            } catch (error: Exception) {
                status = if (isEnglish) "Invalid project file: ${error.message ?: "Read error"}" else "فایل پروژه نامعتبر است: ${error.message ?: "خطای خواندن"}"
            }
        }
    }

    fun saveProject() {
        val json = JSONObject()
        val clipArray = JSONArray()
        clips.forEach { clip ->
            clipArray.put(JSONObject().apply {
                put("uri", clip.uri.toString())
                put("label", clip.label)
                put("startMs", clip.startMs)
                put("endMs", clip.endMs ?: JSONObject.NULL)
            })
        }
        json.put("format", "codenegar-project")
        json.put("version", 2)
        json.put("clips", clipArray)
        json.put("selectedIndex", selectedIndex)
        json.put("musicUri", musicUri?.toString() ?: "")
        json.put("musicVolume", musicVolume.toDouble())
        json.put("overlayText", overlayText)
        json.put("overlayColorIndex", overlayColorIndex)
        json.put("overlayPosition", overlayPosition)
        pendingProjectJson = json.toString(2)
        saveProjectLauncher.launch("CodeNegar_Project_${System.currentTimeMillis()}.json")
    }

    fun splitSelectedClip() {
        if (clips.isEmpty() || durationMs <= 0L) {
            Toast.makeText(context, tx(isEnglish, "ابتدا یک کلیپ را پخش کن", "Play a clip first"), Toast.LENGTH_SHORT).show()
            return
        }
        val clip = clips[selectedIndex]
        val splitAt = (clip.startMs + player.currentPosition).coerceAtLeast(clip.startMs)
        val clipEnd = clip.endMs ?: (clip.startMs + durationMs)
        if (splitAt <= clip.startMs + 250L || splitAt >= clipEnd - 250L) {
            Toast.makeText(context, tx(isEnglish, "نشانگر را حداقل ۰٫۲۵ ثانیه از ابتدا و انتها فاصله بده", "Move the playhead at least 0.25 seconds away from the start and end"), Toast.LENGTH_LONG).show()
            return
        }
        clips[selectedIndex] = clip.copy(label = "${clip.label} (1)", endMs = splitAt)
        clips.add(selectedIndex + 1, clip.copy(label = "${clip.label} (2)", startMs = splitAt, endMs = clipEnd))
        val nextIndex = selectedIndex + 1
        refreshPlaylist(nextIndex, false)
        status = if (isEnglish) "Clip split at ${clock(splitAt - clip.startMs)}; two separate segments created" else "کلیپ در نقطه ${clock(splitAt - clip.startMs)} تقسیم شد؛ دو بخش مستقل ساخته شد"
    }

    fun exportProject() {
        if (clips.isEmpty() || exporting) return
        val output = File(context.getExternalFilesDir(null), "CodeNegar_Project_${System.currentTimeMillis()}.mp4")
        val editedItems = clips.mapIndexed { index, clip ->
            val start = if (index == selectedIndex && durationMs > 0L) clip.startMs + trimStartMs else clip.startMs
            val end = if (index == selectedIndex && durationMs > 0L) {
                (clip.startMs + trimEndMs).coerceAtLeast(start + 1L).coerceAtMost(clip.endMs ?: (clip.startMs + durationMs))
            } else clip.endMs ?: C.TIME_END_OF_SOURCE
            val mediaItem = MediaItem.Builder().setUri(clip.uri)
                .setClippingConfiguration(ClippingConfiguration.Builder()
                    .setStartPositionMs(start).setEndPositionMs(end).build()).build()
            val editedBuilder = EditedMediaItem.Builder(mediaItem)
            if (overlayText.isNotBlank()) {
                editedBuilder.setEffects(
                    Effects(emptyList(), listOf(buildTextOverlayEffect(
                        overlayText,
                        overlayColors[overlayColorIndex],
                        overlayPosition
                    )))
                )
            }
            editedBuilder.build()
        }
        exporting = true
        status = if (isEnglish) "Combining ${clips.size} clip(s) and creating an MP4 file…" else "در حال ترکیب ${clips.size} کلیپ و ساخت یک فایل MP4…"
        val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedItems)
        val sequences = mutableListOf(videoSequence)
        musicUri?.let { audioUri ->
            val musicItem = EditedMediaItem.Builder(MediaItem.fromUri(audioUri)).build()
            val musicSequence = EditedMediaItemSequence.withAudioFrom(listOf(musicItem))
                .buildUpon().setIsLooping(true).build()
            sequences.add(musicSequence)
        }
        val composition = Composition.Builder(sequences).build()
        Transformer.Builder(context).addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                exporting = false
                status = if (isEnglish) "Exported ${clips.size} clip(s): ${output.name}" else "پروژه با ${clips.size} کلیپ خروجی گرفته شد: ${output.name}"
                Toast.makeText(context, tx(isEnglish, "ویدیوی نهایی در پوشه اختصاصی Code Negar ذخیره شد", "Final video saved in the Code Negar folder"), Toast.LENGTH_LONG).show()
            }
            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                exporting = false
                status = if (isEnglish) "Export error: ${exportException.message ?: "Unknown"}" else "خطای خروجی: ${exportException.message ?: "نامشخص"}"
                Toast.makeText(context, status, Toast.LENGTH_LONG).show()
            }
        }).build().start(composition, output.absolutePath)
    }

    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text(tx(isEnglish, "متن روی ویدیو", "Text overlay")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = overlayText,
                        onValueChange = { overlayText = it.take(120) },
                        label = { Text(tx(isEnglish, "متن دلخواه", "Custom text")) },
                        placeholder = { Text(if (isEnglish) "e.g. CODE NEGAR" else "مثلاً: CODE NEGAR") },
                        singleLine = false,
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(tx(isEnglish, "رنگ متن", "Text color"), color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        overlayColors.forEachIndexed { index, color ->
                            FilterChip(
                                selected = overlayColorIndex == index,
                                onClick = { overlayColorIndex = index },
                                label = { Text(listOf(tx(isEnglish, "سفید", "White"), tx(isEnglish, "زرد", "Yellow"), tx(isEnglish, "فیروزه‌ای", "Cyan"), tx(isEnglish, "قرمز", "Red"))[index]) }
                            )
                        }
                    }
                    Text(tx(isEnglish, "موقعیت متن", "Text position"), color = Muted, fontSize = 12.sp)
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        listOf(tx(isEnglish, "پایین", "Bottom"), tx(isEnglish, "وسط", "Center"), tx(isEnglish, "بالا", "Top")).forEachIndexed { index, label ->
                            SegmentedButton(
                                selected = overlayPosition == index,
                                onClick = { overlayPosition = index },
                                shape = SegmentedButtonDefaults.itemShape(index, 3)
                            ) { Text(label) }
                        }
                    }
                    Text(tx(isEnglish, "متن انتخاب‌شده در پیش‌نمایش و خروجی نهایی قرار می‌گیرد.", "The selected text will appear in the preview and final export."),
                        color = Muted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showTextDialog = false }) { Text(tx(isEnglish, "ثبت متن", "Apply text")) }
            },
            dismissButton = {
                TextButton(onClick = { overlayText = ""; showTextDialog = false }) { Text(tx(isEnglish, "حذف متن", "Remove text")) }
            }
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Neon, secondary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isEnglish) LayoutDirection.Ltr else LayoutDirection.Rtl) {
        Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(horizontal = 13.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(Neon, Cyan))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Code, null, tint = Color.White)
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("CODE NEGAR", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp)
                    Text("GAMING VIDEO EDITOR", color = Cyan, fontSize = 9.sp, letterSpacing = 1.8.sp)
                }
                IconButton(onClick = { loadProjectLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }) {
                    Icon(Icons.Default.FolderOpen, tx(isEnglish, "باز کردن پروژه", "Open project"), tint = Cyan)
                }
                IconButton(onClick = { saveProject() }) {
                    Icon(Icons.Default.Save, tx(isEnglish, "ذخیره پروژه", "Save project"), tint = Neon)
                }
                TextButton(onClick = {
                    isEnglish = !isEnglish
                    status = if (isEnglish) "Language changed to English" else "زبان برنامه به فارسی تغییر کرد"
                }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
                    Text(if (isEnglish) "فارسی" else "EN", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text("V2.0", color = Muted, fontSize = 10.sp)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StatChip(tx(isEnglish, "کلیپ‌ها", "CLIPS"), clips.size.toString(), Modifier.weight(1f))
                StatChip(tx(isEnglish, "انتخاب‌شده", "SELECTED"), if (clips.isEmpty()) "—" else "${selectedIndex + 1}/${clips.size}", Modifier.weight(1f))
                StatChip(tx(isEnglish, "موتور", "ENGINE"), "MEDIA3", Modifier.weight(1f))
            }
            Spacer(Modifier.height(9.dp))

            Box(Modifier.fillMaxWidth().weight(0.85f).clip(RoundedCornerShape(17.dp))
                .background(Color(0xFF03050A)).border(1.dp, Panel2, RoundedCornerShape(17.dp)),
                contentAlignment = Alignment.Center) {
                if (clips.isNotEmpty()) {
                    AndroidView(factory = { ctx -> PlayerView(ctx).apply {
                        player = player
                        useController = false
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    } }, modifier = Modifier.fillMaxSize())
                    if (overlayText.isNotBlank()) {
                        Text(
                            text = overlayText,
                            color = Color(overlayColors[overlayColorIndex]),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.align(when (overlayPosition) {
                                0 -> Alignment.BottomCenter
                                1 -> Alignment.Center
                                else -> Alignment.TopCenter
                            }).padding(18.dp)
                        )
                    }
                    Box(Modifier.align(Alignment.BottomEnd).padding(8.dp)
                        .background(Color.Black.copy(alpha = .7f), CircleShape).padding(7.dp)) {
                        Text("CLIP ${selectedIndex + 1}", color = Cyan, fontSize = 10.sp)
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VideoLibrary, null, tint = Neon, modifier = Modifier.size(48.dp))
                        Text(tx(isEnglish, "پروژه جدید", "New project"), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(tx(isEnglish, "چند ویدیو انتخاب کن تا پشت سر هم پخش شوند", "Choose videos to play them one after another"), color = Muted, fontSize = 10.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { multiPicker.launch(arrayOf("video/*")) },
                            colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text(tx(isEnglish, "افزودن چند ویدیو", "Add videos"))
                        }
                    }
                }
            }

            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(clock(positionMs), color = Cyan, fontSize = 10.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = {
                    if (clips.isNotEmpty()) {
                        if (player.isPlaying) {
                            player.pause()
                            musicPlayer.pause()
                        } else {
                            player.play()
                            if (musicUri != null) musicPlayer.play()
                        }
                    }
                }, enabled = clips.isNotEmpty()) {
                    Icon(if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                        null, tint = Color.White, modifier = Modifier.size(37.dp))
                }
                Spacer(Modifier.weight(1f))
                Text(clock(durationMs), color = Muted, fontSize = 10.sp)
            }
            if (clips.isNotEmpty() && durationMs > 0L) {
                Slider(value = positionMs.toFloat().coerceIn(0f, durationMs.toFloat()),
                    onValueChange = { positionMs = it.toLong(); player.seekTo(positionMs) },
                    valueRange = 0f..durationMs.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Neon))
                Text(if (isEnglish) "Current clip trim: ${clock(trimStartMs)} to ${clock(trimEndMs)}" else "بازه برش کلیپ فعلی: ${clock(trimStartMs)} تا ${clock(trimEndMs)}",
                    color = Muted, fontSize = 9.sp)
                RangeSlider(
                    value = trimStartMs.toFloat().coerceIn(0f, durationMs.toFloat())..trimEndMs.toFloat().coerceIn(0f, durationMs.toFloat()),
                    onValueChange = { range ->
                        trimStartMs = range.start.toLong()
                        trimEndMs = range.endInclusive.toLong()
                    },
                    valueRange = 0f..durationMs.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Neon)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        trimStartMs = positionMs.coerceIn(0L, durationMs)
                        if (trimEndMs <= trimStartMs) trimEndMs = durationMs
                    }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                        Text(tx(isEnglish, "تعیین شروع", "Set start"), fontSize = 10.sp)
                    }
                    OutlinedButton(onClick = {
                        trimEndMs = positionMs.coerceIn(trimStartMs + 1, durationMs)
                    }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                        Text(tx(isEnglish, "تعیین پایان", "Set end"), fontSize = 10.sp)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(tx(isEnglish, "TIMELINE / کلیپ‌ها", "TIMELINE / CLIPS"), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = { multiPicker.launch(arrayOf("video/*")) }) {
                    Icon(Icons.Default.Add, null, tint = Cyan, modifier = Modifier.size(16.dp))
                    Text(tx(isEnglish, "افزودن چندتایی", "Add multiple"), color = Cyan, fontSize = 10.sp)
                }
            }
            if (clips.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(11.dp))
                    .background(Panel), contentAlignment = Alignment.Center) {
                    Text(tx(isEnglish, "تایم‌لاین خالی است", "Timeline is empty"), color = Muted, fontSize = 11.sp)
                }
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 112.dp).clip(RoundedCornerShape(11.dp))
                    .background(Panel).padding(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    itemsIndexed(clips, key = { index, clip -> "${clip.uri}-$index" }) { index, clip ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                            .background(if (index == selectedIndex) Color(0xFF30234F) else Panel2)
                            .clickable {
                                selectedIndex = index
                                player.seekTo(index, 0L)
                                player.pause()
                            }.padding(horizontal = 7.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text(clip.label, color = Color.White, fontSize = 10.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                if (index > 0) {
                                    val item = clips.removeAt(index)
                                    clips.add(index - 1, item)
                                    refreshPlaylist(index - 1, false)
                                }
                            }, enabled = index > 0, modifier = Modifier.size(27.dp)) {
                                Icon(Icons.Default.KeyboardArrowUp, null, tint = if (index > 0) Cyan else Muted,
                                    modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = {
                                if (index < clips.lastIndex) {
                                    val item = clips.removeAt(index)
                                    clips.add(index + 1, item)
                                    refreshPlaylist(index + 1, false)
                                }
                            }, enabled = index < clips.lastIndex, modifier = Modifier.size(27.dp)) {
                                Icon(Icons.Default.KeyboardArrowDown, null,
                                    tint = if (index < clips.lastIndex) Cyan else Muted, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = {
                                clips.removeAt(index)
                                val next = if (clips.isEmpty()) 0 else index.coerceAtMost(clips.lastIndex)
                                refreshPlaylist(next, false)
                                status = tx(isEnglish, "کلیپ حذف شد", "Clip removed")
                            }, modifier = Modifier.size(27.dp)) {
                                Icon(Icons.Default.Delete, null, tint = Color(0xFFFF6B83), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(7.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                val tools = listOf("clips", "trim", "split", "speed", "audio", "text", "filter", "effects")
                val icons = listOf(Icons.Default.VideoLibrary, Icons.Default.ContentCut, Icons.Default.CallSplit,
                    Icons.Default.Speed, Icons.Default.MusicNote, Icons.Default.TextFields,
                    Icons.Default.Tune, Icons.Default.AutoAwesome)
                items(tools.size) { i ->
                    MiniTool(toolLabel(tools[i], isEnglish), icons[i], selectedTool == tools[i]) {
                        selectedTool = tools[i]
                        when (tools[i]) {
                            "split" -> splitSelectedClip()
                            "clips" -> Toast.makeText(context, tx(isEnglish, "از دکمه‌های بالا/پایین ترتیب کلیپ‌ها را تغییر بده.", "Use the up/down buttons to reorder clips."), Toast.LENGTH_SHORT).show()
                            "audio" -> audioPicker.launch(arrayOf("audio/*"))
                            "text" -> showTextDialog = true
                            else -> Toast.makeText(context, if (isEnglish) "${toolLabel(tools[i], true)} is still in development." else "ابزار ${toolLabel(tools[i], false)} هنوز در حال توسعه است.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            if (musicUri != null) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel)
                    .padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, null, tint = Cyan)
                    Spacer(Modifier.width(6.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tx(isEnglish, "موسیقی پس‌زمینه فعال", "Background music enabled"), color = Color.White, fontSize = 10.sp)
                        Text(if (isEnglish) "Volume: ${(musicVolume * 100).toInt()}%" else "صدا: ${(musicVolume * 100).toInt()}٪", color = Muted, fontSize = 9.sp)
                    }
                    Slider(value = musicVolume, onValueChange = {
                        musicVolume = it
                        musicPlayer.volume = it
                    }, modifier = Modifier.weight(1.2f), colors = SliderDefaults.colors(
                        thumbColor = Cyan, activeTrackColor = Neon))
                    IconButton(onClick = {
                        player.pause()
                        musicPlayer.stop()
                        musicUri = null
                        status = tx(isEnglish, "موسیقی پس‌زمینه حذف شد", "Background music removed")
                    }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, tx(isEnglish, "حذف موسیقی", "Remove music"), tint = Color(0xFFFF6B83))
                    }
                }
            } else {
                Text(tx(isEnglish, "موسیقی: هنوز انتخاب نشده — از ابزار «صدا» فایل صوتی اضافه کن", "Music: not selected — add an audio file using the Audio tool"),
                    color = Muted, fontSize = 9.sp, modifier = Modifier.padding(vertical = 3.dp))
            }

            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { multiPicker.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(4.dp)); Text(tx(isEnglish, "افزودن", "Add"))
                }
                Button(onClick = { if (clips.isEmpty()) Toast.makeText(context, tx(isEnglish, "ابتدا ویدیو وارد کن", "Add a video first"), Toast.LENGTH_SHORT).show()
                    else if (!exporting) exportProject() },
                    enabled = clips.isNotEmpty() && !exporting, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                    if (exporting) CircularProgressIndicator(Modifier.size(15.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.FileDownload, null)
                    Spacer(Modifier.width(4.dp)); Text(tx(isEnglish, "خروجی کل پروژه", "Export project"))
                }
            }
            Text(if (isEnglish) "Project can be saved/restored • ${clips.size} clips • Code Negar 2.0" else "پروژه قابل ذخیره/بازیابی است • ${clips.size} کلیپ • Code Negar 2.0", color = Cyan.copy(alpha = .8f), fontSize = 8.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 2.dp))
            Text(status, color = Muted, fontSize = 9.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp, bottom = 5.dp))
        }
        }
    }
}

private fun toolLabel(key: String, english: Boolean): String = when (key) {
    "clips" -> tx(english, "کلیپ‌ها", "Clips")
    "trim" -> tx(english, "برش", "Trim")
    "split" -> tx(english, "تقسیم", "Split")
    "speed" -> tx(english, "سرعت", "Speed")
    "audio" -> tx(english, "صدا", "Audio")
    "text" -> tx(english, "متن", "Text")
    "filter" -> tx(english, "فیلتر", "Filter")
    else -> tx(english, "افکت", "Effects")
}

@OptIn(UnstableApi::class)
private fun buildTextOverlayEffect(text: String, color: Int, position: Int): OverlayEffect {
    val styled = SpannableString(text)
    if (text.isNotEmpty()) {
        styled.setSpan(ForegroundColorSpan(color), 0, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        styled.setSpan(AbsoluteSizeSpan(42, true), 0, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        styled.setSpan(StyleSpan(Typeface.BOLD), 0, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    val y = when (position) { 0 -> -0.78f; 1 -> 0f; else -> 0.78f }
    val settings = StaticOverlaySettings.Builder()
        .setBackgroundFrameAnchor(0f, y)
        .setOverlayFrameAnchor(0f, 0f)
        .setAlphaScale(1f)
        .build()
    return OverlayEffect(listOf(TextOverlay.createStaticTextOverlay(styled, settings)))
}

@Composable
private fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(9.dp)).background(Panel).padding(8.dp)) {
        Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
        Text(value, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MiniTool(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                     selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(61.dp).clip(RoundedCornerShape(10.dp))
        .background(if (selected) Color(0xFF30234F) else Panel)
        .border(if (selected) 1.dp else 0.dp, if (selected) Neon else Panel, RoundedCornerShape(10.dp))
        .clickable(onClick = onClick).padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected) Cyan else Muted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(3.dp))
        Text(title, color = Color.White, fontSize = 9.sp)
    }
}

private fun clock(ms: Long): String {
    val seconds = ms.coerceAtLeast(0L) / 1000L
    return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
}
